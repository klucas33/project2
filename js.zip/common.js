$(function(){
    // include
    
    $('footer').load('inc.html footer > article');

    

});